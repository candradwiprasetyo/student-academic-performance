<div class="w-full h-10"></div>
<script>
    window.onload = function() {
        const alertBox = document.getElementById('alert');
        if (alertBox) {
            setTimeout(() => {
                alertBox.style.display = 'none';
            }, 3000); 
        }
    };
</script>
</body>
</html>